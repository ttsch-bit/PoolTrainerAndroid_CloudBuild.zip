# Pool Trainer Android — MVP

Kotlin ile hazırlanmış bağımsız bilardo eğitim simülatörü.

## Özellikler
- Yatay ekran düzeni ve bilardo masası.
- Topları parmağınla sürükleyerek yerleştirme.
- Güç ve açı ayarları.
- Ayarlara göre güncellenen yaklaşık rota tahmini.
- Beyaz topu sürükleyip bırakarak basit vuruş animasyonu.
- Sıfırlama düğmesi.

## Bilgisayar olmadan APK oluşturma (GitHub Actions)

Bu kaynak kod ZIP'i önceden derlenmiş APK değildir. APK'yı ücretsiz bulut derlemesiyle oluşturmak için GitHub hesabı gerekir.

1. Telefonda GitHub hesabına giriş yap veya hesap oluştur: https://github.com
2. Yeni bir **public repository** oluştur (ör. `PoolTrainerAndroid`).
3. Bu ZIP dosyasını depoya yükle ve dosya adını `PoolTrainerAndroid_CloudBuild.zip` olarak kullan.
4. Depoda **Add file → Create new file** seç ve dosya yoluna `.github/workflows/build-apk.yml` yaz.
5. Ayrı verilen `build-apk.yml` dosyasının içeriğini bu dosyaya yapıştır ve **Commit changes** seç.
6. Depodaki **Actions** sekmesine gir, **Build Pool Trainer APK** iş akışını seç, ardından **Run workflow** düğmesine bas.
7. İşlem yeşil tik ile tamamlanınca çalıştırma sayfasındaki **Artifacts** bölümünden `PoolTrainer-debug-apk` dosyasını indir. İnen ZIP'i açıp `app-debug.apk` dosyasını çıkar.
8. APK'ya dokunup yükle. Samsung bilinmeyen uygulama izni isterse yalnızca indirme yaptığın uygulamaya izin ver.

GitHub Actions, kodu senin hesabında bulutta derler. İşlem başarısız olursa Actions sayfasındaki hata günlüğü gerekir. GitHub arayüzünde ZIP yükleme veya dosya oluşturma seçeneği görünmüyorsa tarayıcı menüsünden **Masaüstü sitesi** görünümünü açmayı dene.

## Android Studio
Yerel derleme için Android Studio ve Android SDK Platform 35 gerekir.

## Sınırlar
Bu bağımsız eğitim simülatörüdür; 8 Ball Pool'a bağlanmaz, oyun belleğini okumaz/değiştirmez ve oyun üzerinde canlı overlay çizmez. Fizik modeli yaklaşık olup Miniclip'in özel fiziğiyle kalibre edilmemiştir.
