package com.example.pooltrainer

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var table: PoolView
    private fun dp(v:Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9,15,13)
        window.navigationBarColor = Color.rgb(9,15,13)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12),dp(8),dp(12),dp(6))
            setBackgroundColor(Color.rgb(9,15,13))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "POOL TRAINER  /  EĞİTİM SİMÜLATÖRÜ"
            textSize = 18f; setTextColor(Color.rgb(92,245,160))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0,dp(38),1f))
        val reset = Button(this).apply { text = "Sıfırla"; setOnClickListener { table.resetTable() } }
        header.addView(reset)
        root.addView(header)
        table = PoolView(this)
        root.addView(table, LinearLayout.LayoutParams(-1,0,1f))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(makeControl("GÜÇ", 65) { table.power = it/100f; table.invalidate() },
            LinearLayout.LayoutParams(0,dp(65),1f))
        controls.addView(makeControl("AÇI", 0, 360) { table.angle = Math.toRadians(it.toDouble()).toFloat(); table.invalidate() },
            LinearLayout.LayoutParams(0,dp(65),1f))
        root.addView(controls)
        root.addView(TextView(this).apply {
            text = "Topları sürükle • Güç ve açıyı değiştir • Beyaz topu sürükleyip bırak: vuruş"
            textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY)
        })
        setContentView(root)
    }
    private fun makeControl(label:String, initial:Int, maxValue:Int=100, onChange:(Int)->Unit): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8),0,dp(8),0) }
        val txt = TextView(this).apply { text = "$label  $initial${if(label=="GÜÇ") "%" else "°"}"; setTextColor(Color.WHITE) }
        col.addView(txt)
        col.addView(SeekBar(this).apply {
            max=maxValue; progress=initial
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s:SeekBar?, v:Int, user:Boolean) {
                    txt.text="$label  $v${if(label=="GÜÇ") "%" else "°"}"; onChange(v)
                }
                override fun onStartTrackingTouch(s:SeekBar?) {}
                override fun onStopTrackingTouch(s:SeekBar?) {}
            })
        })
        return col
    }
}
