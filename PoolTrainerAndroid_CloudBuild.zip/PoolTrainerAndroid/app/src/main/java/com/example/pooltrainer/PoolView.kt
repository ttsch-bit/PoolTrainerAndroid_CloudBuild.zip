package com.example.pooltrainer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

private data class Ball(var x:Float,var y:Float,var vx:Float=0f,var vy:Float=0f,val color:Int,val number:Int)
private data class Pt(val x:Float,val y:Float)

class PoolView(context:Context): View(context) {
    var power=0.65f
    var angle=0f
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private val balls= mutableListOf<Ball>()
    private var l=0f; private var t=0f; private var r=0f; private var b=0f
    private var radius=8f
    private var selected=-1

    init { resetTable() }

    fun resetTable() {
        balls.clear()
        balls.add(Ball(.24f,.5f,color=Color.WHITE,number=0))
        val colors=intArrayOf(Color.YELLOW,Color.BLUE,Color.RED,Color.MAGENTA,0xffff9900.toInt(),Color.BLACK,Color.CYAN,0xff8833bb.toInt(),0xffe5d34b.toInt())
        var n=1
        for(row in 0..3) for(col in 0..row) {
            balls.add(Ball(.68f+row*.04f,.5f+(col-row/2f)*.085f,color=colors[(n-1)%colors.size],number=n)); n++
        }
        invalidate()
    }

    override fun onDraw(c:Canvas) {
        super.onDraw(c)
        val margin=min(width*.035f,height*.07f)
        l=margin; t=margin; r=width-margin; b=height-margin
        radius=min((r-l)*.014f,(b-t)*.027f).coerceAtLeast(5f)
        paint.style=Paint.Style.FILL
        paint.color=0xff704120.toInt(); c.drawRoundRect(l-8,t-8,r+8,b+8,18f,18f,paint)
        paint.color=0xff00954d.toInt(); c.drawRoundRect(l,t,r,b,10f,10f,paint)
        paint.color=0xff00b85a.toInt(); c.drawRect(l+8,t+8,r-8,b-8,paint)
        paint.color=0xff07110b.toInt()
        listOf(Pt(l,t),Pt((l+r)/2,t),Pt(r,t),Pt(l,b),Pt((l+r)/2,b),Pt(r,b)).forEach { c.drawCircle(it.x,it.y,radius*1.8f,paint) }

        val trajectories=predict()
        paint.style=Paint.Style.STROKE; paint.strokeWidth=max(2f,radius*.18f)
        paint.color=0xff50ffa0.toInt(); drawLinePath(c,trajectories.first)
        paint.color=0xff4a9bff.toInt(); drawLinePath(c,trajectories.second)
        paint.style=Paint.Style.FILL

        val cue=balls.first()
        paint.color=0xbbffffff.toInt(); paint.style=Paint.Style.STROKE
        c.drawLine(cue.x,cue.y,cue.x+cos(angle)*((r-l)*.25f),cue.y+sin(angle)*((r-l)*.25f),paint)
        paint.style=Paint.Style.FILL

        balls.forEach { ball ->
            paint.color=ball.color; c.drawCircle(ball.x,ball.y,radius,paint)
            if(ball.number>0) {
                paint.color=if(ball.color==Color.BLACK) Color.WHITE else Color.BLACK
                paint.textAlign=Paint.Align.CENTER; paint.textSize=radius
                c.drawText(ball.number.toString(),ball.x,ball.y+radius*.35f,paint)
            }
            paint.color=0x88000000.toInt(); paint.style=Paint.Style.STROKE
            c.drawCircle(ball.x,ball.y,radius,paint); paint.style=Paint.Style.FILL
        }
        paint.color=Color.WHITE; paint.textSize=11f; paint.textAlign=Paint.Align.LEFT
        c.drawText("YEŞİL: Beyaz top rotası   MAVİ: İlk hedef top rotası   •   Tahmin modeli",l,b+1,paint)
    }

    private fun drawLinePath(c:Canvas, pts:List<Pt>) {
        if(pts.size<2) return
        val path=Path(); path.moveTo(pts[0].x,pts[0].y)
        pts.drop(1).forEach { path.lineTo(it.x,it.y) }
        c.drawPath(path,paint)
        val end=pts.last(); paint.style=Paint.Style.FILL; c.drawCircle(end.x,end.y,radius*.8f,paint); paint.style=Paint.Style.STROKE
    }

    private fun predict():Pair<List<Pt>,List<Pt>> {
        if(balls.isEmpty() || r<=l || b<=t) return Pair(emptyList(),emptyList())
        val sim=balls.map { it.copy(vx=0f,vy=0f) }.toMutableList()
        val speed=(r-l)*(.18f+power*1.1f)
        sim[0].vx=cos(angle)*speed; sim[0].vy=sin(angle)*speed
        val path0=mutableListOf<Pt>(); val path1=mutableListOf<Pt>()
        var target=-1
        repeat(1300) { step ->
            sim.forEach { it.x+=it.vx*.018f; it.y+=it.vy*.018f }
            sim.forEach {
                if(it.x<l+radius){it.x=l+radius;it.vx=abs(it.vx)*.82f}
                if(it.x>r-radius){it.x=r-radius;it.vx=-abs(it.vx)*.82f}
                if(it.y<t+radius){it.y=t+radius;it.vy=abs(it.vy)*.82f}
                if(it.y>b-radius){it.y=b-radius;it.vy=-abs(it.vy)*.82f}
            }
            for(i in sim.indices) for(j in i+1 until sim.size) {
                val a=sim[i]; val q=sim[j]; val dx=q.x-a.x; val dy=q.y-a.y
                val d2=dx*dx+dy*dy; val minD=radius*2
                if(d2>.01f && d2<minD*minD) {
                    val d=sqrt(d2); val nx=dx/d; val ny=dy/d
                    val rel=(a.vx-q.vx)*nx+(a.vy-q.vy)*ny
                    if(rel>0) { a.vx-=rel*nx; a.vy-=rel*ny; q.vx+=rel*nx; q.vy+=rel*ny }
                    val overlap=minD-d
                    a.x-=nx*overlap*.5f; a.y-=ny*overlap*.5f
                    q.x+=nx*overlap*.5f; q.y+=ny*overlap*.5f
                    if(i==0 && target<0) target=j
                }
            }
            sim.forEach { it.vx*=.988f; it.vy*=.988f }
            if(step%5==0) {
                path0.add(Pt(sim[0].x,sim[0].y))
                if(target>=0) path1.add(Pt(sim[target].x,sim[target].y))
            }
            if(sim.all { abs(it.vx)+abs(it.vy)<1f }) return Pair(path0,path1)
        }
        return Pair(path0,path1)
    }

    override fun onTouchEvent(e:MotionEvent):Boolean {
        when(e.action) {
            MotionEvent.ACTION_DOWN -> {
                selected=balls.indices.minByOrNull { hypot((e.x-balls[it].x).toDouble(),(e.y-balls[it].y).toDouble()) } ?: -1
                if(selected>=0 && hypot((e.x-balls[selected].x).toDouble(),(e.y-balls[selected].y).toDouble())<radius*2.5) return true
                selected=-1; return true
            }
            MotionEvent.ACTION_MOVE -> {
                if(selected>=0) {
                    balls[selected].x=e.x.coerceIn(l+radius,r-radius)
                    balls[selected].y=e.y.coerceIn(t+radius,b-radius)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if(selected==0) shoot()
                selected=-1; invalidate(); return true
            }
        }
        return true
    }

    private fun shoot() {
        val cue=balls[0]
        cue.vx=cos(angle)*(r-l)*(.18f+power*1.1f)
        cue.vy=sin(angle)*(r-l)*(.18f+power*1.1f)
        var count=0
        val task=object:Runnable {
            override fun run() {
                if(count++>180) { balls.forEach { it.vx=0f;it.vy=0f }; invalidate(); return }
                balls.forEach {
                    it.x+=it.vx*.016f; it.y+=it.vy*.016f
                    if(it.x<l+radius || it.x>r-radius) it.vx *= -.8f
                    if(it.y<t+radius || it.y>b-radius) it.vy *= -.8f
                    it.x=it.x.coerceIn(l+radius,r-radius); it.y=it.y.coerceIn(t+radius,b-radius)
                    it.vx*=.985f; it.vy*=.985f
                }
                for(i in balls.indices) for(j in i+1 until balls.size) {
                    val a=balls[i]; val q=balls[j]; val dx=q.x-a.x; val dy=q.y-a.y; val d=hypot(dx,dy)
                    if(d>0.1f && d<radius*2) {
                        val nx=dx/d; val ny=dy/d
                        val rel=(a.vx-q.vx)*nx+(a.vy-q.vy)*ny
                        if(rel>0) { a.vx-=rel*nx; a.vy-=rel*ny; q.vx+=rel*nx; q.vy+=rel*ny }
                    }
                }
                invalidate(); postOnAnimation(this)
            }
        }
        postOnAnimation(task)
    }
}
